# Anonymous-review release checklist

This directory is designed as an export package, not as a fork of an identifiable development repository.

Before sharing it with reviewers:

1. Create a **new repository under a neutral account** or upload a ZIP to a service intended for anonymous peer review.
2. Initialise a **fresh Git history**. Do not fork, mirror with history, or push a branch whose parent commits expose an author name or account.
3. Use neutral commit metadata, for example `Anonymous Authors <anonymous@invalid.example>`.
4. Add a `repository-code` field to `CITATION.cff` only if the neutral review URL does not reveal identity.
5. Run `python scripts/00_validate.py --strict --anonymity`.
6. Inspect the hosting page itself: account name, organisation, avatar, commit signature, issue history, actions logs and release metadata can all disclose identity even when files are clean.
7. Do not add the manuscript, cover letter, tracked-changes files, acknowledgements, funding identifiers or personalised configuration.

After acceptance, replace the anonymous citation metadata with the final authors, article DOI and permanent repository/archive DOI. This post-acceptance metadata update should not be made during double-anonymous review.
